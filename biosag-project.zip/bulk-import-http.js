const https = require('https');
const fs = require('fs');

// Koristimo Sanity HTTP API direktno
const PROJECT_ID = 'beba1xg7';
const DATASET = 'production';
const API_VERSION = '2024-02-09';

// Ova funkcija šalje HTTP zahtev ka Sanity API-ju
function createDocument(doc, token) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify({ mutations: [{ create: doc }] });

        const options = {
            hostname: `${PROJECT_ID}.api.sanity.io`,
            port: 443,
            path: `/v${API_VERSION}/data/mutate/${DATASET}`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length,
                'Authorization': `Bearer ${token}`
            }
        };

        const req = https.request(options, (res) => {
            let responseData = '';
            res.on('data', (chunk) => { responseData += chunk; });
            res.on('end', () => {
                if (res.statusCode === 200) {
                    resolve(JSON.parse(responseData));
                } else {
                    reject(new Error(`HTTP ${res.statusCode}: ${responseData}`));
                }
            });
        });

        req.on('error', reject);
        req.write(data);
        req.end();
    });
}

async function importFAQs() {
    // Token će biti prosleđen kao environment varijabla
    const token = process.env.SANITY_TOKEN;

    if (!token) {
        console.error('❌ GREŠKA: SANITY_TOKEN nije postavljen!');
        console.log('\n💡 Kreirajte token na: https://www.sanity.io/manage/personal/tokens');
        console.log('   Zatim pokrenite: SANITY_TOKEN=vaš_token node bulk-import-http.js');
        process.exit(1);
    }

    try {
        console.log('📖 Učitavam FAQ pitanja...\n');
        const ndjson = fs.readFileSync('faqs.ndjson', 'utf8');
        const lines = ndjson.split('\n').filter(line => line.trim());

        console.log(`✅ Pronađeno ${lines.length} FAQ pitanja\n`);
        console.log('🚀 Počinjem import...\n');

        let imported = 0;
        let failed = 0;

        for (let i = 0; i < lines.length; i++) {
            const doc = JSON.parse(lines[i]);
            delete doc._id; // Sanity će generisati novi ID
            doc._type = 'faq';

            try {
                await createDocument(doc, token);
                imported++;
                console.log(`✓ [${i + 1}/${lines.length}] ${doc.question.substring(0, 60)}...`);
            } catch (err) {
                failed++;
                console.error(`✗ [${i + 1}/${lines.length}] Greška: ${err.message}`);
            }

            // Pauza između zahteva da ne preopteretimo API
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        console.log(`\n🎉 Import završen!`);
        console.log(`   ✅ Uspešno: ${imported}`);
        console.log(`   ❌ Neuspešno: ${failed}`);
        console.log(`\n✅ Osvežite http://localhost:3000 da vidite sve FAQ-ove!`);

    } catch (err) {
        console.error('❌ Kritična greška:', err.message);
    }
}

importFAQs();
