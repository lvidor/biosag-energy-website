
const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    // CLI handles auth, or we run with `npx sanity exec`
});

// Hardcoded content from AboutSection.tsx to seed the DB
const initialAbout = {
    _id: 'about',
    _type: 'about',
    title: 'O nama',
    subtitle: 'Vaš partner za pametnu automatizaciju',
    description: [
        {
            _type: 'block',
            children: [
                {
                    _type: 'span',
                    text: 'Biosag Energy DOO je vodeća kompanija u oblasti automatizacije kuća i zgrada u Srbiji. Osnovani 2016. godine, specijalizovali smo se za profesionalnu instalaciju i održavanje Loxone sistema - najnaprednijeg rešenja za pametne domove na tržištu.',
                    marks: []
                }
            ],
            markDefs: [],
            style: 'normal'
        },
        {
            _type: 'block',
            children: [
                {
                    _type: 'span',
                    text: 'Naš tim stručnjaka pruža kompletna rešenja - od planiranja i projektovanja, preko instalacije, do konfiguracije i dugotrajne podrške. Bilo da želite da poboljšate energetsku efikasnost, povećate udobnost ili sigurnost vašeg doma ili poslovnog prostora, mi smo tu da vam pomognemo.',
                    marks: []
                }
            ],
            markDefs: [],
            style: 'normal'
        },
        {
            _type: 'block',
            children: [
                {
                    _type: 'span',
                    text: 'Kao Loxone Silver Partner, garantujemo najviši nivo stručnosti i kvaliteta usluge. Vaš dom može raditi za vas - dozvolite nam da vam pokažemo kako.',
                    marks: []
                }
            ],
            markDefs: [],
            style: 'normal'
        }
    ],
    yearFounded: 2016,
    stats: [
        { number: '2016', label: 'Godina osnivanja' },
        { number: '100+', label: 'Realizovanih projekata' },
        { number: 'Loxone', label: 'Silver Partner' }
    ]
};

async function createAbout() {
    try {
        const res = await client.createIfNotExists(initialAbout);
        console.log('About document created:', res._id);
    } catch (err) {
        console.error('Error creating about:', err.message);
    }
}

createAbout();
