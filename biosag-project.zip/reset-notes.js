
const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    token: process.env.SANITY_API_TOKEN || '', // We'll try without token first if public, but likely need one.
    // Actually, we need a token to delete. 
    // Since we don't have the token in env, we will ask the user to run this with their token OR better yet:
    // We can use the CLI which is authenticated.
    useCdn: false,
});

// Wait, the CLI is authenticated. Let's use the CLI to delete.
// npx sanity documents delete siteSettings
