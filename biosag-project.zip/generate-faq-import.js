
const { createClient } = require('@sanity/client');
const fs = require('fs');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    token: process.env.SANITY_API_TOKEN || 'skREPLACE_ME_WITH_REAL_TOKEN_IF_NEEDED_BUT_API_IS_PUBLIC_SO_MAYBE_NOT' // Actually we need a write token
});

// We need a token to write data. Since we don't have one in env, we might need to ask user or use the studio.
// However, the studio is authenticated.
// Let's try to use the dataset if it's public (usually not for writes).
// If writes fail, we'll need to guide the user to import via CLI or manually.

// Actually, wait. The user is logged in to the Studio.
// The best way to import is to create a .ndjson file and use `sanity dataset import` command if they have the CLI.
// Or we can just output the NDJSON and ask them to run the command?
// No, I can try to use the token if I can find it, but I can't.

// Let's create an NDJSON file for import. It's safer and cleaner.
// "sanity dataset import faqs.ndjson production"

const content = fs.readFileSync('faq_content.md', 'utf8');
const lines = content.split('\n');

let faqs = [];
let currentFaq = {};
let parsing = false;

for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line.startsWith('### ')) {
        if (Object.keys(currentFaq).length > 0) {
            faqs.push(currentFaq);
        }
        // Start new FAQ
        const title = line.replace('### ', '').replace(/^\d+\.\s*/, '');
        currentFaq = {
            _type: 'faq',
            question: title
        };
    } else if (line.startsWith('**Kategorija:**')) {
        currentFaq.category = line.split('**')[2].trim();
    } else if (line.startsWith('**Redosled:**')) {
        currentFaq.order = parseInt(line.split('**')[2].trim());
    } else if (line.startsWith('**Odgovor:**')) {
        currentFaq.answer = line.replace('**Odgovor:**', '').trim();
    } else if (currentFaq.answer && line !== '' && !line.startsWith('---') && !line.startsWith('## ')) {
        currentFaq.answer += ' ' + line;
    }
}
if (Object.keys(currentFaq).length > 0) {
    faqs.push(currentFaq);
}

// Write to NDJSON
const ndjson = faqs.map(faq => JSON.stringify(faq)).join('\n');
fs.writeFileSync('faqs.ndjson', ndjson);

console.log(`Created faqs.ndjson with ${faqs.length} entries.`);
console.log('To import run:');
console.log('npx sanity dataset import faqs.ndjson production --replace');
