import { ContactForm } from "./ContactForm";

export function ContactSection() {
    return <ContactForm />;
}
