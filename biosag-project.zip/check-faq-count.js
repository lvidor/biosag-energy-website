
const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
});

async function checkCount() {
    try {
        const count = await client.fetch(`count(*[_type == "faq"])`);
        console.log(`FAQ Count: ${count}`);
    } catch (err) {
        console.error(err.message);
    }
}

checkCount();
