const { createClient } = require('@sanity/client');
const fs = require('fs');

// Čistimo token od svih whitespace karaktera
const rawToken = process.env.SANITY_TOKEN;

if (!rawToken) {
    console.error('❌ GREŠKA: SANITY_TOKEN nije postavljen!');
    console.log('Pokrenite: SANITY_TOKEN=vaš_token node clean-import.js');
    process.exit(1);
}

// Uklanjamo sve razmake, nove redove, tabove
const token = rawToken.trim().replace(/\s/g, '');

console.log(`🔑 Token dužina: ${token.length} karaktera`);
console.log(`🔑 Token počinje sa: ${token.substring(0, 10)}...`);

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    token: token,
    useCdn: false,
});

async function importFAQs() {
    try {
        console.log('\n📖 Učitavam FAQ pitanja...\n');
        const ndjson = fs.readFileSync('faqs.ndjson', 'utf8');
        const lines = ndjson.split('\n').filter(line => line.trim());

        console.log(`✅ Pronađeno ${lines.length} FAQ pitanja\n`);
        console.log('🚀 Počinjem import...\n');

        let imported = 0;
        let failed = 0;

        for (let i = 0; i < lines.length; i++) {
            const doc = JSON.parse(lines[i]);
            delete doc._id;

            try {
                const result = await client.create(doc);
                imported++;
                console.log(`✓ [${i + 1}/${lines.length}] ${doc.question.substring(0, 60)}...`);
            } catch (err) {
                failed++;
                console.error(`✗ [${i + 1}/${lines.length}] Greška: ${err.message}`);

                // Prikazujemo detaljnu grešku samo za prvo pitanje
                if (i === 0) {
                    console.error('\n📋 Detaljna greška za prvo pitanje:');
                    console.error(err);
                }
            }

            await new Promise(resolve => setTimeout(resolve, 200));
        }

        console.log(`\n🎉 Import završen!`);
        console.log(`   ✅ Uspešno: ${imported}`);
        console.log(`   ❌ Neuspešno: ${failed}`);

        if (imported > 0) {
            console.log(`\n✅ Osvežite http://localhost:3000 da vidite sve FAQ-ove!`);
        }

    } catch (err) {
        console.error('❌ Kritična greška:', err.message);
        console.error(err);
    }
}

importFAQs();
