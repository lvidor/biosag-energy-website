
const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
});

async function fetchSettings() {
    const settings = await client.fetch('*[_type == "siteSettings"][0]');
    console.log(JSON.stringify(settings, null, 2));
}

fetchSettings();
