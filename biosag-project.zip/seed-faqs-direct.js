
const { createClient } = require('@sanity/client');
const fs = require('fs');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    // Using CLI auth via 'npx sanity exec'
});

const faqData = [
    {
        question: "Šta je Loxone sistem i kako funkcioniše?",
        answer: "Loxone je sveobuhvatan sistem automatizacije koji centralno upravlja svim aspektima vašeg doma...",
        category: "Opšte",
        order: 1
    },
    {
        question: "Koliko košta ugradnja pametnog sistema?",
        answer: "Cena zavisi od veličine objekta i željenih funkcionalnosti. Nudimo rešenja prilagođena različitim budžetima...",
        category: "Cene",
        order: 2
    },
    // ... (Adding a subset first to test, but user asked for all. logic below reads from file if possible or uses this array)
];

// Better approach: Parse the existing md file or use the json we created earlier if it exists/is valid.
// Actually, let's just read the NDJSON we made earlier, parse it, and create documents using the client directly.
// This avoids the 'sanity dataset import' failure.

async function seedFaqs() {
    try {
        const ndjson = fs.readFileSync('faqs.ndjson', 'utf8');
        const lines = ndjson.split('\n').filter(line => line.trim());

        console.log(`Found ${lines.length} FAQs to import.`);

        const transaction = client.transaction();

        lines.forEach(line => {
            const doc = JSON.parse(line);
            // Remove _id to let Sanity generate new ones to avoid conflicts or use deterministic IDs
            delete doc._id;
            transaction.create(doc);
        });

        const res = await transaction.commit();
        console.log('Successfully imported FAQs:', res.results.length);
    } catch (err) {
        console.error('Migration failed:', err.message);
    }
}

seedFaqs();
