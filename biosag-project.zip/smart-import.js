const { createClient } = require('@sanity/client');
const fs = require('fs');

// Koristimo PUBLIC API (read-only) da proverimo stanje
const publicClient = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
});

// Koristimo lokalni token iz .env.local (ako postoji)
const writeClient = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    token: process.env.SANITY_API_TOKEN, // Iz .env.local
});

async function smartImport() {
    try {
        console.log('🔍 Proveravam trenutno stanje...\n');

        const existing = await publicClient.fetch(`*[_type == "faq"]{_id, question}`);
        console.log(`📊 Trenutno u bazi: ${existing.length} FAQ pitanja`);

        if (existing.length > 0) {
            console.log('\nPostojeća pitanja:');
            existing.forEach((faq, i) => {
                console.log(`  ${i + 1}. ${faq.question}`);
            });
        }

        console.log('\n📖 Učitavam FAQ pitanja iz faqs.ndjson...');
        const ndjson = fs.readFileSync('faqs.ndjson', 'utf8');
        const lines = ndjson.split('\n').filter(line => line.trim());
        const newFaqs = lines.map(line => JSON.parse(line));

        console.log(`✅ Pronađeno ${newFaqs.length} FAQ pitanja za import.\n`);

        // Filtriramo samo ona koja ne postoje
        const existingQuestions = new Set(existing.map(f => f.question));
        const toImport = newFaqs.filter(faq => !existingQuestions.has(faq.question));

        if (toImport.length === 0) {
            console.log('✅ Sva pitanja već postoje u bazi!');
            return;
        }

        console.log(`🚀 Importujem ${toImport.length} novih pitanja...\n`);

        let imported = 0;
        for (let i = 0; i < toImport.length; i++) {
            const doc = toImport[i];
            delete doc._id;

            try {
                await writeClient.create(doc);
                imported++;
                console.log(`✓ [${i + 1}/${toImport.length}] ${doc.question.substring(0, 60)}...`);
            } catch (err) {
                if (err.message.includes('Insufficient permissions')) {
                    console.error('\n❌ GREŠKA: Nemate dozvolu za kreiranje dokumenata.');
                    console.log('\n💡 REŠENJE:');
                    console.log('Pošto nemate pristup Sanity projektu, mogu da kreiram NOVI projekat za vas.');
                    console.log('Ili možete ručno dodati FAQ pitanja kroz Studio na localhost:3000/studio');
                    return;
                }
                console.error(`✗ [${i + 1}/${toImport.length}] Greška: ${err.message}`);
            }
        }

        console.log(`\n🎉 Import završen! Uspešno: ${imported}`);

    } catch (err) {
        console.error('❌ Greška:', err.message);
    }
}

smartImport();
