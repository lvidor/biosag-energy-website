
const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
});

async function debugFaqs() {
    try {
        console.log("Fetching all documents with _type 'faq'...");
        const faqs = await client.fetch(`*[_type == "faq"]{_id, question, category}`);
        console.log(`Found ${faqs.length} FAQs:`);
        faqs.forEach(f => console.log(`- [${f._id}] ${f.question} (${f.category})`));

        if (faqs.length < 5) {
            console.log("\nFetching ALL documents to check for misnamed types...");
            const allDocs = await client.fetch(`*[!(_type match "system.*")][0...20]{_id, _type, title, question}`);
            console.log("Sample of first 20 documents:");
            allDocs.forEach(d => console.log(`- [${d._type}] ${d.title || d.question || d._id}`));
        }
    } catch (err) {
        console.error("Error:", err.message);
    }
}

debugFaqs();
