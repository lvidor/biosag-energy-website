/**
 * Script to add Hungarian translations to Sanity CMS
 * This will update Hero, Features, and FAQ documents with Hungarian fields
 */

const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || 'uxbp7yy5',
    dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || 'production',
    useCdn: false,
    token: process.env.SANITY_API_TOKEN,
    apiVersion: '2024-01-01',
});

// Hungarian translations
const hungarianTranslations = {
    hero: {
        titleHu: 'Okos energia az otthonának',
        subtitleHu: 'Loxone automatizálás és naperőművek',
        ctaHu: 'Kapcsolatfelvétel'
    },
    features: [
        {
            title: 'Loxone Smart Home Sistemi',
            titleHu: 'Loxone Smart Home Rendszerek',
            descriptionHu: 'Komplett okosotthon megoldások a Loxone rendszerrel - világítás, fűtés, árnyékolás és biztonság egy platformon'
        },
        {
            title: 'Konsultacije i Projektovanje',
            titleHu: 'Konzultáció és Tervezés',
            descriptionHu: 'Szakértői tanácsadás és részletes tervezés az Ön igényei szerint'
        },
        {
            title: 'Električne Instalacije',
            titleHu: 'Villanyszerelési Munkák',
            descriptionHu: 'Professzionális villanyszerelési szolgáltatások és komplett elektromos rendszerek telepítése'
        },
        {
            title: 'Solarne Elektrane',
            titleHu: 'Napelemes Rendszerek',
            descriptionHu: 'Napelemes rendszerek tervezése, telepítése és karbantartása az energiafüggetlenség érdekében'
        },
        {
            title: 'Sigurnost i Nadzor',
            titleHu: 'Biztonság és Felügyelet',
            descriptionHu: 'Videó megfigyelő rendszerek, riasztók és hozzáférés-szabályozás a teljes biztonság érdekében'
        },
        {
            title: 'Podrška i Održavanje',
            titleHu: 'Támogatás és Karbantartás',
            descriptionHu: 'Teljes körű támogatás és rendszeres karbantartás a rendszer zavartalan működéséhez'
        }
    ],
    faqs: [
        {
            question: 'Šta je Loxone sistem?',
            questionHu: 'Mi az a Loxone rendszer?',
            answerHu: 'A Loxone egy komplett okosotthon rendszer, amely egyetlen központi egységből irányítja otthona összes funkcióját - világítás, fűtés, árnyékolás, multiroom audio, biztonság és még sok más.',
            category: 'Loxone rendszer',
            categoryHu: 'Loxone rendszer'
        },
        {
            question: 'Da li imate licence za električne instalacije?',
            questionHu: 'Rendelkeznek villanyszerelési engedéllyel?',
            answerHu: 'Igen, csapatunk rendelkezik minden szükséges engedéllyel és tanúsítvánnyal a villanyszerelési munkák elvégzéséhez. Loxone Silver Partner státusszal is rendelkezünk.',
            category: 'Elektromos szerelés',
            categoryHu: 'Villanyszerelés'
        },
        {
            question: 'Da li mogu da instaliram Loxone u postojećoj kući?',
            questionHu: 'Telepíthető a Loxone meglévő házba?',
            answerHu: 'Igen, a Loxone rendszer meglévő házakba is telepíthető. Bár az új építésű házak esetében egyszerűbb, a meglévő házak is felszerelhetők minimális átalakítással.',
            category: 'Loxone rendszer',
            categoryHu: 'Loxone rendszer'
        },
        {
            question: 'Da li Loxone radi sa postojećim uređajima?',
            questionHu: 'Működik a Loxone a meglévő eszközökkel?',
            answerHu: 'Igen, a Loxone integrálható számos meglévő eszközzel és rendszerrel, beleértve a KNX-et, Modbus-t, DMX-et és sok más protokollt.',
            category: 'Loxone rendszer',
            categoryHu: 'Loxone rendszer'
        },
        {
            question: 'Šta se dešava ako nestane interneta?',
            questionHu: 'Mi történik, ha nincs internet?',
            answerHu: 'A Loxone rendszer teljesen offline működik. Az internet csak a távoli hozzáféréshez szükséges - minden automatizálás és vezérlés helyben, a Miniserverben fut.',
            category: 'Loxone rendszer',
            categoryHu: 'Loxone rendszer'
        },
        {
            question: 'Da li mogu da kontrolišem kuću sa telefona?',
            questionHu: 'Irányíthatom a házat telefonról?',
            answerHu: 'Igen, a Loxone alkalmazás iOS-re és Androidra is elérhető. Bárhonnan irányíthatja otthonát, akár otthon van, akár úton.',
            category: 'Loxone rendszer',
            categoryHu: 'Loxone rendszer'
        },
        {
            question: 'Koje usluge nudite?',
            questionHu: 'Milyen szolgáltatásokat kínálnak?',
            answerHu: 'Teljes körű szolgáltatásokat nyújtunk: konzultáció, tervezés, villanyszerelés, Loxone telepítés, napelemes rendszerek, videó megfigyelés és folyamatos támogatás.',
            category: 'Általános',
            categoryHu: 'Általános'
        },
        {
            question: 'Koliko traje instalacija?',
            questionHu: 'Mennyi ideig tart a telepítés?',
            answerHu: 'A telepítési idő az ingatlan méretétől és a kért funkciók számától függ. Egy átlagos családi ház 2-4 hetet vesz igénybe a tervezéstől a befejezésig.',
            category: 'Telepítés',
            categoryHu: 'Telepítés'
        },
        {
            question: 'Da li mogu da nadograđujem sistem kasnije?',
            questionHu: 'Bővíthető a rendszer később?',
            answerHu: 'Igen, a Loxone rendszer moduláris felépítésű. Bármikor hozzáadhat új funkciókat és eszközöket a rendszerhez.',
            category: 'Karbantartás',
            categoryHu: 'Karbantartás'
        },
        {
            question: 'Koliko košta Loxone sistem?',
            questionHu: 'Mennyibe kerül a Loxone rendszer?',
            answerHu: 'A költség az ingatlan méretétől és a kért funkcióktól függ. Használja az Okosotthon Árkalkulátorunkat egy gyors becsléshez, vagy kérjen részletes ajánlatot.',
            category: 'Árak és fizetés',
            categoryHu: 'Árak és fizetés'
        }
    ]
};

async function updateHero() {
    console.log('Updating Hero with Hungarian translations...');

    const hero = await client.fetch(`*[_type == "hero"][0]`);

    if (!hero) {
        console.log('No hero found, skipping...');
        return;
    }

    await client
        .patch(hero._id)
        .set(hungarianTranslations.hero)
        .commit();

    console.log('✅ Hero updated successfully!');
}

async function updateFeatures() {
    console.log('Updating Features with Hungarian translations...');

    const features = await client.fetch(`*[_type == "feature"] | order(order asc)`);

    for (const translation of hungarianTranslations.features) {
        const feature = features.find(f => f.title === translation.title);

        if (feature) {
            await client
                .patch(feature._id)
                .set({
                    titleHu: translation.titleHu,
                    descriptionHu: translation.descriptionHu
                })
                .commit();

            console.log(`✅ Updated feature: ${translation.title}`);
        } else {
            console.log(`⚠️  Feature not found: ${translation.title}`);
        }
    }

    console.log('✅ All features updated!');
}

async function updateFAQs() {
    console.log('Updating FAQs with Hungarian translations...');

    const faqs = await client.fetch(`*[_type == "faq"]`);

    for (const translation of hungarianTranslations.faqs) {
        const faq = faqs.find(f => f.question === translation.question);

        if (faq) {
            await client
                .patch(faq._id)
                .set({
                    questionHu: translation.questionHu,
                    answerHu: translation.answerHu,
                    categoryHu: translation.categoryHu
                })
                .commit();

            console.log(`✅ Updated FAQ: ${translation.question.substring(0, 50)}...`);
        } else {
            console.log(`⚠️  FAQ not found: ${translation.question.substring(0, 50)}...`);
        }
    }

    console.log('✅ All FAQs updated!');
}

async function main() {
    try {
        console.log('🚀 Starting Hungarian translation import...\n');

        await updateHero();
        console.log('');

        await updateFeatures();
        console.log('');

        await updateFAQs();
        console.log('');

        console.log('🎉 All Hungarian translations added successfully!');
        console.log('You can now test the site at http://localhost:3000/hu');
    } catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    }
}

main();
