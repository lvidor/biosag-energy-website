const { createClient } = require('@sanity/client');
const fs = require('fs');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    token: process.env.SANITY_API_TOKEN
});

async function fetchFAQs() {
    try {
        console.log('Fetching all FAQs from Sanity...');
        const faqs = await client.fetch(`*[_type == "faq"] | order(order asc){
            _id,
            question,
            answer,
            category,
            order
        }`);

        console.log(`Found ${faqs.length} FAQs\n`);

        // Save to JSON file for translation
        fs.writeFileSync('faqs-for-translation.json', JSON.stringify(faqs, null, 2));
        console.log('✅ Saved to faqs-for-translation.json');

        // Also create a simple text format for easy translation
        let textOutput = '';
        faqs.forEach((faq, index) => {
            textOutput += `\n=== FAQ ${index + 1} ===\n`;
            textOutput += `ID: ${faq._id}\n`;
            textOutput += `QUESTION (SR): ${faq.question}\n`;
            textOutput += `ANSWER (SR): ${faq.answer}\n`;
            textOutput += `---\n`;
        });

        fs.writeFileSync('faqs-text.txt', textOutput);
        console.log('✅ Saved to faqs-text.txt');

    } catch (error) {
        console.error('Error fetching FAQs:', error);
    }
}

fetchFAQs();
