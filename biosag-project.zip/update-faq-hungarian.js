const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    token: process.env.SANITY_API_TOKEN
});

// Serbian to Hungarian translations for FAQ questions and answers
const translations = {
    // Question 1
    "Šta je Loxone sistem?": "Mi a Loxone rendszer?",
    "Loxone je austrijski sistem za automatizaciju kuća i zgrada koji omogućava centralizovanu kontrolu osvetljenja, grejanja, hlađenja, roletni, audio sistema, sigurnosti i mnogih drugih funkcija putem jedne aplikacije.": "A Loxone egy osztrák okosotthon-automatizálási rendszer, amely lehetővé teszi a világítás, fűtés, hűtés, redőnyök, audio rendszerek, biztonság és sok más funkció központi vezérlését egyetlen alkalmazáson keresztül.",

    // Question 2
    "Da li je potrebno rušenje zidova za instalaciju?": "Szükséges-e falak bontása a telepítéshez?",
    "Ne, Loxone sistem se može instalirati bez rušenja zidova. Koristimo postojeće instalacije i dodajemo pametne module. Za nova gradnja, preporučujemo planiranje od početka.": "Nem, a Loxone rendszer telepíthető falak bontása nélkül. A meglévő elektromos hálózatot használjuk és okos modulokat adunk hozzá. Új építkezésnél javasoljuk a tervezést az elejétől.",

    // Question 3
    "Da li mogu da instaliram Loxone u postojeću kuću?": "Telepíthetem-e a Loxone-t meglévő házba?",
    "Da, Loxone se može instalirati u postojeće kuće. Naši stručnjaci će proceniti vašu trenutnu instalaciju i predložiti najbolje rešenje za vašu situaciju.": "Igen, a Loxone telepíthető meglévő házakba. Szakértőink felmérik a jelenlegi elektromos rendszert és a legjobb megoldást javasolják az Ön helyzetéhez.",

    // Question 4
    "Da li Loxone radi sa postojećim uređajima?": "Működik-e a Loxone meglévő eszközökkel?",
    "Loxone može da se integriše sa mnogim postojećim uređajima i sistemima. Kompatibilnost zavisi od konkretnih uređaja, ali većina modernih sistema može da se poveže.": "A Loxone számos meglévő eszközzel és rendszerrel integrálható. A kompatibilitás az adott eszközöktől függ, de a legtöbb modern rendszer csatlakoztatható.",

    // Question 5
    "Šta se dešava ako nestane interneta?": "Mi történik, ha megszűnik az internet?",
    "Loxone sistem radi lokalno i ne zavisi od internet konekcije. Sve automatizacije i kontrole funkcionišu normalno. Internet je potreban samo za daljinski pristup van kuće.": "A Loxone rendszer helyben működik és nem függ az internetkapcsolattól. Minden automatizálás és vezérlés normálisan működik. Az internet csak a távoli hozzáféréshez szükséges otthonon kívülről.",

    // Question 6
    "Da li mogu da nadograđujem sistem kasnije?": "Bővíthetem-e a rendszert később?",
    "Da, Loxone sistem je modularan i može se lako proširivati. Možete početi sa osnovnim funkcijama i dodavati nove mogućnosti kako vam odgovara.": "Igen, a Loxone rendszer moduláris és könnyen bővíthető. Kezdheti az alapfunkciókkal és később új lehetőségeket adhat hozzá, ahogy Önnek megfelel.",

    // Question 7
    "Koje funkcije Loxone sistem podržava?": "Milyen funkciókat támogat a Loxone rendszer?",
    "Loxone podržava osvetljenje, grejanje, hlađenje, roletne, audio/video, sigurnost, alarmni sistem, kontrolu pristupa, navodnjavanje, bazen, solarnu energiju i mnogo više.": "A Loxone támogatja a világítást, fűtést, hűtést, redőnyöket, audio/videót, biztonságot, riasztórendszert, beléptető rendszert, öntözést, medencét, napenergiát és még sok mást.",

    // Question 8
    "Koje usluge nudite?": "Milyen szolgáltatásokat kínálnak?",
    "Nudimo kompletna rešenja: konsultacije, projektovanje, instalaciju Loxone sistema, solarne elektrane, električne instalacije, servis i podršku.": "Teljes körű megoldásokat kínálunk: tanácsadás, tervezés, Loxone rendszer telepítése, napelemes rendszerek, elektromos szerelés, szerviz és támogatás.",

    // Question 9
    "Koliko traje instalacija?": "Mennyi ideig tart a telepítés?",
    "Vreme instalacije zavisi od veličine projekta. Prosečan stan se instalira za 3-5 dana, kuća za 1-2 nedelje. Dajemo preciznu procenu nakon pregleda objekta.": "A telepítési idő a projekt méretétől függ. Egy átlagos lakás 3-5 nap alatt, egy ház 1-2 hét alatt telepíthető. Pontos becslést adunk az ingatlan megtekintése után.",

    // Question 10
    "Da li mogu da kontrolišem kuću sa telefona?": "Vezérelhetem-e a házat telefonról?",
    "Da, Loxone aplikacija je dostupna za iOS i Android uređaje. Možete kontrolisati sve funkcije vašeg doma sa bilo kog mesta na svetu.": "Igen, a Loxone alkalmazás elérhető iOS és Android eszközökre. Az otthona minden funkcióját vezérelheti a világ bármely pontjáról.",

    // Question 11
    "Koliko dugo traje projekat od početka do kraja?": "Mennyi ideig tart a projekt az elejétől a végéig?",
    "Kompletan projekat obično traje 4-8 nedelja: konsultacije (1 nedelja), projektovanje (1-2 nedelje), nabavka opreme (1-2 nedelje), instalacija (1-2 nedelje), testiranje i obuka (3-5 dana).": "A teljes projekt általában 4-8 hetet vesz igénybe: konzultáció (1 hét), tervezés (1-2 hét), eszközbeszerzés (1-2 hét), telepítés (1-2 hét), tesztelés és oktatás (3-5 nap).",

    // Question 12
    "Da li nudite obuku za korišćenje sistema?": "Kínálnak-e oktatást a rendszer használatához?",
    "Da, nakon instalacije pružamo detaljnu obuku za sve korisnike. Pokazujemo kako da koristite aplikaciju, podešavate scene i rešavate osnovne probleme.": "Igen, a telepítés után részletes oktatást nyújtunk minden felhasználónak. Megmutatjuk, hogyan kell használni az alkalmazást, jeleneteket beállítani és alapvető problémákat megoldani.",

    // Question 13
    "Šta ako nešto prestane da radi?": "Mi van, ha valami leáll?",
    "Nudimo tehničku podršku i servis. Većina problema se može rešiti na daljinu. Za hardverske probleme dolazimo na lice mesta. Imamo ugovor o održavanju sa brzim odzivom.": "Technikai támogatást és szervizszolgáltatást nyújtunk. A legtöbb probléma távolról megoldható. Hardveres problémák esetén a helyszínre érkezünk. Gyors reagálású karbantartási szerződést kínálunk.",

    // Question 14
    "Da li sistem zahteva održavanje?": "Igényel-e a rendszer karbantartást?",
    "Loxone sistem je vrlo pouzdan i ne zahteva često održavanje. Preporučujemo godišnji pregled i ažuriranje softvera. Nudimo pakete održavanja.": "A Loxone rendszer nagyon megbízható és nem igényel gyakori karbantartást. Éves ellenőrzést és szoftverfrissítést javasolunk. Karbantartási csomagokat kínálunk.",

    // Question 15
    "Koliko košta Loxone sistem?": "Mennyibe kerül a Loxone rendszer?",
    "Cena zavisi od veličine objekta i željenih funkcija. Prosečan stan (60m²) od €3.000, kuća (150m²) od €8.000. Kontaktirajte nas za besplatnu procenu.": "Az ár az ingatlan méretétől és a kívánt funkcióktól függ. Átlagos lakás (60m²) 3.000 €-tól, ház (150m²) 8.000 €-tól. Lépjen kapcsolatba velünk ingyenes árajánlatért.",

    // Question 16
    "Da li nudite finansiranje?": "Kínálnak-e finanszírozást?",
    "Da, sarađujemo sa bankama i nudimo opcije finansiranja. Možete platiti na rate sa povoljnim uslovima. Kontaktirajte nas za detalje.": "Igen, bankokkal együttműködve finanszírozási lehetőségeket kínálunk. Kedvező feltételekkel részletekben fizethet. Lépjen kapcsolatba velünk a részletekért.",

    // Question 17
    "Šta je uključeno u cenu?": "Mi tartozik az árba?",
    "Cena uključuje: konsultacije, projektovanje, opremu, instalaciju, programiranje, testiranje i obuku. Dodatni troškovi mogu biti za specijalne zahteve ili premium opremu.": "Az ár tartalmazza: konzultációt, tervezést, berendezést, telepítést, programozást, tesztelést és oktatást. További költségek merülhetnek fel speciális igények vagy prémium berendezések esetén.",

    // Question 18
    "Da li dajete garanciju?": "Adnak-e garanciát?",
    "Da, sva oprema ima proizvođačku garanciju (obično 2-5 godina). Naša instalacija ima garanciju 2 godine. Nudimo i produženu garanciju.": "Igen, minden berendezésre gyártói garancia vonatkozik (általában 2-5 év). Telepítésünkre 2 év garancia van. Meghosszabbított garanciát is kínálunk.",

    // Question 19
    "Koliko energije štedi Loxone sistem?": "Mennyi energiát takarít meg a Loxone rendszer?",
    "Loxone može smanjiti potrošnju energije za 30-50% kroz inteligentno upravljanje grejanjem, hlađenjem, osvetljenjem i automatizacijom. Investicija se vraća za 3-7 godina.": "A Loxone 30-50%-kal csökkentheti az energiafogyasztást az intelligens fűtés-, hűtés-, világítás- és automatizáláskezelés révén. A befektetés 3-7 év alatt megtérül.",

    // Question 20
    "Da li radite solarne elektrane?": "Telepítenek-e napelemes rendszereket?",
    "Da, projektujemo i instaliramo solarne elektrane za domaćinstva i preduzeća. Loxone se integriše sa solarnim sistemima za optimalno upravljanje energijom.": "Igen, napelemes rendszereket tervezünk és telepítünk háztartások és vállalkozások számára. A Loxone integrálódik a napelemes rendszerekkel az optimális energiakezelés érdekében."
};

async function updateFAQsWithHungarian() {
    try {
        console.log('Fetching existing FAQs...');
        const faqs = await client.fetch(`*[_type == "faq"]{_id, question, answer}`);

        console.log(`Found ${faqs.length} FAQs`);

        let updated = 0;
        let skipped = 0;

        for (const faq of faqs) {
            const questionHu = translations[faq.question];
            const answerHu = translations[faq.answer];

            if (questionHu && answerHu) {
                console.log(`Updating: ${faq.question}`);
                await client
                    .patch(faq._id)
                    .set({
                        questionHu: questionHu,
                        answerHu: answerHu
                    })
                    .commit();
                updated++;
            } else {
                console.log(`Skipping (no translation): ${faq.question}`);
                skipped++;
            }
        }

        console.log(`\n✅ Update complete!`);
        console.log(`   Updated: ${updated} FAQs`);
        console.log(`   Skipped: ${skipped} FAQs`);

    } catch (error) {
        console.error('Error updating FAQs:', error);
    }
}

updateFAQsWithHungarian();
