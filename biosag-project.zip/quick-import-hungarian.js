#!/usr/bin/env node

/**
 * Quick Hungarian Translation Import
 * Run with: SANITY_TOKEN=your_token node quick-import-hungarian.js
 */

const https = require('https');

const PROJECT_ID = 'beba1xg7';
const DATASET = 'production';
const API_VERSION = '2024-01-01';
const TOKEN = process.env.SANITY_TOKEN;

if (!TOKEN) {
    console.error('❌ Error: SANITY_TOKEN environment variable is required!');
    console.log('\n📝 How to get a token:');
    console.log('1. Go to: https://www.sanity.io/manage/personal/tokens');
    console.log('2. Click "Add API token"');
    console.log('3. Name: "Hungarian Import", Permissions: "Writer" or "Editor"');
    console.log('4. Copy the token');
    console.log('\n🚀 Then run:');
    console.log('SANITY_TOKEN=your_token node quick-import-hungarian.js\n');
    process.exit(1);
}

// Hungarian translations
const translations = {
    hero: {
        titleHu: 'Okos energia az otthonának',
        subtitleHu: 'Loxone automatizálás és naperőművek',
        ctaHu: 'Kapcsolatfelvétel'
    },
    features: {
        'Loxone Smart Home Sistemi': {
            titleHu: 'Loxone Smart Home Rendszerek',
            descriptionHu: 'Komplett okosotthon megoldások a Loxone rendszerrel - világítás, fűtés, árnyékolás és biztonság egy platformon'
        },
        'Konsultacije i Projektovanje': {
            titleHu: 'Konzultáció és Tervezés',
            descriptionHu: 'Szakértői tanácsadás és részletes tervezés az Ön igényei szerint'
        },
        'Električne Instalacije': {
            titleHu: 'Villanyszerelési Munkák',
            descriptionHu: 'Professzionális villanyszerelési szolgáltatások és komplett elektromos rendszerek telepítése'
        },
        'Solarne Elektrane': {
            titleHu: 'Napelemes Rendszerek',
            descriptionHu: 'Napelemes rendszerek tervezése, telepítése és karbantartása az energiafüggetlenség érdekében'
        },
        'Sigurnost i Nadzor': {
            titleHu: 'Biztonság és Felügyelet',
            descriptionHu: 'Videó megfigyelő rendszerek, riasztók és hozzáférés-szabályozás a teljes biztonság érdekében'
        },
        'Podrška i Održavanje': {
            titleHu: 'Támogatás és Karbantartás',
            descriptionHu: 'Teljes körű támogatás és rendszeres karbantartás a rendszer zavartalan működéséhez'
        }
    },
    faqs: {
        'Šta je Loxone sistem?': {
            questionHu: 'Mi az a Loxone rendszer?',
            answerHu: 'A Loxone egy komplett okosotthon rendszer, amely egyetlen központi egységből irányítja otthona összes funkcióját - világítás, fűtés, árnyékolás, multiroom audio, biztonság és még sok más.',
            categoryHu: 'Loxone rendszer'
        },
        'Da li imate licence za električne instalacije?': {
            questionHu: 'Rendelkeznek villanyszerelési engedéllyel?',
            answerHu: 'Igen, csapatunk rendelkezik minden szükséges engedéllyel és tanúsítvánnyal a villanyszerelési munkák elvégzéséhez. Loxone Silver Partner státusszal is rendelkezünk.',
            categoryHu: 'Villanyszerelés'
        },
        'Da li mogu da instaliram Loxone u postojećoj kući?': {
            questionHu: 'Telepíthető a Loxone meglévő házba?',
            answerHu: 'Igen, a Loxone rendszer meglévő házakba is telepíthető. Bár az új építésű házak esetében egyszerűbb, a meglévő házak is felszerelhetők minimális átalakítással.',
            categoryHu: 'Loxone rendszer'
        },
        'Da li Loxone radi sa postojećim uređajima?': {
            questionHu: 'Működik a Loxone a meglévő eszközökkel?',
            answerHu: 'Igen, a Loxone integrálható számos meglévő eszközzel és rendszerrel, beleértve a KNX-et, Modbus-t, DMX-et és sok más protokollt.',
            categoryHu: 'Loxone rendszer'
        },
        'Šta se dešava ako nestane interneta?': {
            questionHu: 'Mi történik, ha nincs internet?',
            answerHu: 'A Loxone rendszer teljesen offline működik. Az internet csak a távoli hozzáféréshez szükséges - minden automatizálás és vezérlés helyben, a Miniserverben fut.',
            categoryHu: 'Loxone rendszer'
        },
        'Da li mogu da kontrolišem kuću sa telefona?': {
            questionHu: 'Irányíthatom a házat telefonról?',
            answerHu: 'Igen, a Loxone alkalmazás iOS-re és Androidra is elérhető. Bárhonnan irányíthatja otthonát, akár otthon van, akár úton.',
            categoryHu: 'Loxone rendszer'
        },
        'Koje usluge nudite?': {
            questionHu: 'Milyen szolgáltatásokat kínálnak?',
            answerHu: 'Teljes körű szolgáltatásokat nyújtunk: konzultáció, tervezés, villanyszerelés, Loxone telepítés, napelemes rendszerek, videó megfigyelés és folyamatos támogatás.',
            categoryHu: 'Általános'
        },
        'Koliko traje instalacija?': {
            questionHu: 'Mennyi ideig tart a telepítés?',
            answerHu: 'A telepítési idő az ingatlan méretétől és a kért funkciók számától függ. Egy átlagos családi ház 2-4 hetet vesz igénybe a tervezéstől a befejezésig.',
            categoryHu: 'Telepítés'
        },
        'Da li mogu da nadograđujem sistem kasnije?': {
            questionHu: 'Bővíthető a rendszer később?',
            answerHu: 'Igen, a Loxone rendszer moduláris felépítésű. Bármikor hozzáadhat új funkciókat és eszközöket a rendszerhez.',
            categoryHu: 'Karbantartás'
        },
        'Koliko košta Loxone sistem?': {
            questionHu: 'Mennyibe kerül a Loxone rendszer?',
            answerHu: 'A költség az ingatlan méretétől és a kért funkcióktól függ. Használja az Okosotthon Árkalkulátorunkat egy gyors becsléshez, vagy kérjen részletes ajánlatot.',
            categoryHu: 'Árak és fizetés'
        }
    }
};

function sanityRequest(query) {
    return new Promise((resolve, reject) => {
        const encodedQuery = encodeURIComponent(query);
        const options = {
            hostname: `${PROJECT_ID}.api.sanity.io`,
            path: `/v${API_VERSION}/data/query/${DATASET}?query=${encodedQuery}`,
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${TOKEN}`
            }
        };

        https.get(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 200) {
                    resolve(JSON.parse(data).result);
                } else {
                    reject(new Error(`HTTP ${res.statusCode}: ${data}`));
                }
            });
        }).on('error', reject);
    });
}

function sanityPatch(docId, patches) {
    return new Promise((resolve, reject) => {
        const mutation = {
            mutations: [{
                patch: {
                    id: docId,
                    set: patches
                }
            }]
        };

        const postData = JSON.stringify(mutation);
        const options = {
            hostname: `${PROJECT_ID}.api.sanity.io`,
            path: `/v${API_VERSION}/data/mutate/${DATASET}`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData),
                'Authorization': `Bearer ${TOKEN}`
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 200) {
                    resolve(JSON.parse(data));
                } else {
                    reject(new Error(`HTTP ${res.statusCode}: ${data}`));
                }
            });
        });

        req.on('error', reject);
        req.write(postData);
        req.end();
    });
}

async function updateHero() {
    console.log('🏠 Updating Hero...');
    const hero = await sanityRequest('*[_type == "hero"][0]');

    if (!hero) {
        console.log('⚠️  No hero found');
        return;
    }

    await sanityPatch(hero._id, translations.hero);
    console.log('✅ Hero updated!');
}

async function updateFeatures() {
    console.log('\n🎯 Updating Features...');
    const features = await sanityRequest('*[_type == "feature"] | order(order asc)');

    let updated = 0;
    for (const feature of features) {
        const translation = translations.features[feature.title];
        if (translation) {
            await sanityPatch(feature._id, translation);
            console.log(`✅ ${feature.title}`);
            updated++;
        }
    }
    console.log(`✅ Updated ${updated} features!`);
}

async function updateFAQs() {
    console.log('\n❓ Updating FAQs...');
    const faqs = await sanityRequest('*[_type == "faq"]');

    let updated = 0;
    for (const faq of faqs) {
        const translation = translations.faqs[faq.question];
        if (translation) {
            await sanityPatch(faq._id, translation);
            console.log(`✅ ${faq.question.substring(0, 50)}...`);
            updated++;
        }
    }
    console.log(`✅ Updated ${updated} FAQs!`);
}

async function main() {
    console.log('🚀 Starting Hungarian translation import...\n');

    try {
        await updateHero();
        await updateFeatures();
        await updateFAQs();

        console.log('\n🎉 All Hungarian translations added successfully!');
        console.log('\n✅ Test your site:');
        console.log('   Serbian: http://localhost:3000/sr');
        console.log('   Hungarian: http://localhost:3000/hu');
        console.log('\n🚀 Ready to deploy to Loopia!');
    } catch (error) {
        console.error('\n❌ Error:', error.message);
        console.log('\n💡 Make sure your token has "Writer" or "Editor" permissions');
        process.exit(1);
    }
}

main();
