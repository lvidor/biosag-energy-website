const { createClient } = require('@sanity/client');

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    useCdn: false,
    token: process.env.SANITY_API_TOKEN
});

// Complete translations for all 26 FAQs
const hungarianTranslations = [
    {
        _id: "NBILvU5oyT8T10LfifYydF",
        questionHu: "Mi a Loxone rendszer?",
        answerHu: "A Loxone egy osztrák okosotthon-automatizálási rendszer, amely lehetővé teszi a világítás, fűtés, hűtés, redőnyök, audio rendszerek, biztonság és sok más funkció központi vezérlését egyetlen alkalmazáson keresztül."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBcqC",
        questionHu: "Vezérelhetem-e a házat telefonról?",
        answerHu: "Igen, a Loxone alkalmazás elérhető iOS és Android eszközökre, és lehetővé teszi az otthona teljes vezérlését a világ bármely pontjáról. Hangutasításokat is használhat Amazon Alexa vagy Google Assistant segítségével."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbOOl",
        questionHu: "Mennyi ideig tart a telepítés?",
        answerHu: "A telepítési idő az ingatlan méretétől és a funkciók számától függ. Egy átlagos 100-150m²-es házban a telepítés általában 5-10 munkanapot vesz igénybe. Nagyobb vagy összetettebb rendszerek esetén az időtartam hosszabb lehet."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbOgR",
        questionHu: "Milyen szolgáltatásokat kínálnak?",
        answerHu: "Teljes körű megoldásokat kínálunk: Loxone okosotthonok, elektromos szerelés, videomegfigyelés, beléptető rendszerek, napelemes rendszerek, külső automatizálás, valamint minden telepített rendszer karbantartása és támogatása."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbPFn",
        questionHu: "Milyen funkciókat támogat a Loxone rendszer?",
        answerHu: "A Loxone támogatja a világítás, fűtés, légkondicionálás, redőnyök, audio rendszerek, videomegfigyelés, beléptető rendszerek, tűzérzékelés, vízszivárgás-érzékelés, automatikus öntözés, napelem-kezelés és még sok más vezérlését."
    },
    {
        _id: "NBILvU5oyT8T10LfifYznV",
        questionHu: "Bővíthetem-e a rendszert később?",
        answerHu: "Természetesen! A Loxone rendszer moduláris és könnyen bővíthető. Kezdheti az alapfunkciókkal, mint a világítás és redőnyök, majd szükség szerint hozzáadhatja a fűtést, biztonságot, audio rendszert és egyéb funkciókat."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBdHI",
        questionHu: "Mi történik, ha megszűnik az internet?",
        answerHu: "A Loxone rendszer helyben működik és nem függ az internetkapcsolattól. Minden automatizálás, forgatókönyv és vezérlés normálisan működik internet nélkül is. Az internet csak a távoli vezérléshez szükséges az alkalmazáson keresztül, amikor nincs otthon."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBe1M",
        questionHu: "Működik-e a Loxone meglévő eszközökkel?",
        answerHu: "Igen, a Loxone számos meglévő eszközzel és rendszerrel integrálható, mint például Sonos audio, Philips Hue izzók, KNX eszközök, Modbus eszközök és mások. Támogatja az Amazon Alexa és Google Assistant integrációt is."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbQFf",
        questionHu: "Telepíthetem-e a Loxone-t meglévő házba?",
        answerHu: "Igen, a Loxone telepíthető meglévő épületekbe is. Különböző megoldások állnak rendelkezésre attól függően, hogy felújítást tervez-e vagy minimális beavatkozást szeretne. Loxone Air vezeték nélküli megoldásokat is kínálunk."
    },
    {
        _id: "NBILvU5oyT8T10LfifZ1d3",
        questionHu: "Szükséges-e falak bontása a telepítéshez?",
        answerHu: "Nem feltétlenül. Új épületeknél a hagyományos vezetékes telepítést javasoljuk a maximális megbízhatóság érdekében. Meglévő épületeknél Loxone Air megoldásokat kínálunk, amelyek vezeték nélküli kommunikációt használnak és minimalizálják az építési munkálatokat."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBeXs",
        questionHu: "Mennyi ideig tart a projekt az elejétől a végéig?",
        answerHu: "A teljes projekt magában foglalja: konzultációt és tervezést (1-2 hét), eszközbeszerzést (1-2 hét), telepítést (5-15 nap mérettől függően), konfigurálást és tesztelést (2-3 nap), valamint felhasználói oktatást (1 nap). Összesen 4-8 hét egy átlagos ingatlan esetén."
    },
    {
        _id: "NBILvU5oyT8T10LfifZ2Xp",
        questionHu: "Végeznek-e elektromos szerelést új épületekhez?",
        answerHu: "Igen, teljes körű elektromos szerelést végzünk lakó- és kereskedelmi épületekhez az érvényes szabványok szerint. Csapatunk rendelkezik minden szükséges engedéllyel és tanúsítvánnyal. Meglévő telepítések felülvizsgálatát is kínáljuk."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBetY",
        questionHu: "Mennyibe kerül a Loxone rendszer?",
        answerHu: "Az ár az ingatlan méretétől és a kívánt funkcióktól függ. Egy átlagos 100-150m²-es házban az alapvető Loxone rendszer (világítás, redőnyök, fűtés) 5.000-8.000 EUR-tól kezdődik. A teljesebb rendszerek audio, videomegfigyelés és fejlett funkciókkal 12.000-20.000 EUR között lehetnek. Lépjen kapcsolatba velünk ingyenes árajánlatért."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbRSn",
        questionHu: "Adnak-e garanciát?",
        answerHu: "Igen, minden Loxone eszközre 2 év gyártói garancia vonatkozik, telepítésünkre pedig 1 év garanciát adunk. Meghosszabbított garanciákat és karbantartási szolgáltatásokat is kínálunk."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBfFE",
        questionHu: "Milyen fizetési módokat fogadnak el?",
        answerHu: "A projekt során részletekben történő fizetést fogadunk el: 30% előleg a szerződés aláírásakor, 40% a telepítés befejezésekor, és 30% a tesztelés és oktatás után. Átutalást, készpénzt és bankkártyát is elfogadunk."
    },
    {
        _id: "NBILvU5oyT8T10LfifZ32n",
        questionHu: "Kínálnak-e finanszírozást?",
        answerHu: "Jelenleg nem kínálunk közvetlen finanszírozást, de együttműködünk bankokkal, amelyek hiteleket nyújtanak lakásfelújításhoz és -korszerűsítéshez. Segíthetünk a hitelhez szükséges dokumentáció elkészítésében."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBfdc",
        questionHu: "Igényel-e a rendszer karbantartást?",
        answerHu: "A Loxone rendszer nagyon megbízható és nem igényel rendszeres karbantartást. Éves rendszerellenőrzést és szoftverfrissítést javasolunk a rendszer optimális működése érdekében. Elsőbbségi támogatással rendelkező karbantartási szolgáltatásokat kínálunk."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbRkT",
        questionHu: "Mi van, ha valami leáll?",
        answerHu: "Gyors műszaki támogatást nyújtunk. A legtöbb probléma távolról megoldható TeamViewer vagy telefonos támogatás segítségével. Hardveres problémák esetén a helyszínre érkezünk. A sürgős esetekre vonatkozó válaszidő 24 óra. Lépjen kapcsolatba velünk a +381 23 123 456 telefonszámon."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBg7Q",
        questionHu: "Kínálnak-e oktatást a rendszer használatához?",
        answerHu: "Igen, a telepítés után részletes oktatást szervezünk minden felhasználó számára. Megmutatjuk, hogyan kell használni az alkalmazást, forgatókönyveket létrehozni, automatizálásokat beállítani és alapvető problémákat megoldani. További oktatások kérésre elérhetők."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbSAz",
        questionHu: "Telepítenek-e napelemes rendszereket?",
        answerHu: "Igen, teljes körű napelemes megoldásokat kínálunk - a tervezéstől, az eszközbeszerzésen, a telepítésen át a hálózatra való csatlakozásig és a regisztrációig. Neves napelem panel és inverter márkákkal dolgozunk."
    },
    {
        _id: "RJjnIjSCmOs2kB7sdoBguC",
        questionHu: "Mennyibe kerül egy napelemes rendszer egy házhoz?",
        answerHu: "Az ár a rendszer teljesítményétől függ. Egy átlagos családi házhoz egy 5-10 kW-os rendszer telepítéssel együtt 5.000-12.000 EUR között kerül. A rendszer 6-10 év alatt megtérül az áramköltség megtakarításán keresztül. Ingyenes igény- és megtérülési becslést kínálunk."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbSbV",
        questionHu: "Kombinálhatom-e a napelemes rendszert a Loxone rendszerrel?",
        answerHu: "Természetesen! A Loxone nyomon követheti a napelemes termelést és automatikusan kezelheti a fogyasztást - például bekapcsolhatja a bojlert, légkondicionálót vagy elektromos autó töltését, amikor napenergia-többlet van. Ez maximalizálja a megtakarítást."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbTJh",
        questionHu: "Mennyi ideig tart a napelemes rendszer telepítése?",
        answerHu: "Maga a panelek és berendezések telepítése a rendszer méretétől függően 2-5 napot vesz igénybe. A teljes eljárás, beleértve a tervezést, engedélyeket és hálózatra csatlakozást, 4-8 hetet vehet igénybe. Segítünk minden dokumentációban."
    },
    {
        _id: "NBILvU5oyT8T10LfifZ4D3",
        questionHu: "Milyen elektromos szereléseket végeznek?",
        answerHu: "Teljes körű elektromos szerelést végzünk lakó-, kereskedelmi és ipari épületekhez: elosztótáblák, kábelezés, aljzatok, világítás, villámvédelem, földelés, légkondicionáló és bojler csatlakozások. Minden munkát az érvényes szabványok és előírások szerint végzünk."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbTxT",
        questionHu: "Végeznek-e elektromos rendszerek felülvizsgálatát?",
        answerHu: "Igen, szakértői ellenőrzést és felülvizsgálatot végzünk meglévő elektromos rendszereken tanúsítvány kiállításával. Ez kötelező régebbi épületeknél, ingatlanértékesítéskor vagy felújítás után. A felülvizsgálat ára az ingatlan méretétől függ."
    },
    {
        _id: "NII3BdPs0Hw6LwOCvcbUF9",
        questionHu: "Rendelkeznek-e engedélyekkel az elektromos szereléshez?",
        answerHu: "Igen, minden villanyszerelőnk rendelkezik engedéllyel és tanúsítvánnyal. Minden szükséges engedélyünk megvan az elektromos munkák elvégzéséhez és tanúsítványok kiállításához. Az SRPS szabványok szerint dolgozunk és garantáljuk a minőséget és biztonságot."
    }
];

async function updateAllFAQs() {
    try {
        console.log('Starting Hungarian translation update for all FAQs...\n');

        let updated = 0;
        let failed = 0;

        for (const translation of hungarianTranslations) {
            try {
                console.log(`Updating FAQ: ${translation._id}`);
                await client
                    .patch(translation._id)
                    .set({
                        questionHu: translation.questionHu,
                        answerHu: translation.answerHu
                    })
                    .commit();
                updated++;
                console.log(`✓ Success`);
            } catch (error) {
                failed++;
                console.log(`✗ Failed: ${error.message}`);
            }
        }

        console.log(`\n${'='.repeat(50)}`);
        console.log(`✅ Update Complete!`);
        console.log(`   Total FAQs: ${hungarianTranslations.length}`);
        console.log(`   ✓ Updated: ${updated}`);
        console.log(`   ✗ Failed: ${failed}`);
        console.log(`${'='.repeat(50)}\n`);

        if (updated === hungarianTranslations.length) {
            console.log('🎉 All FAQs successfully updated with Hungarian translations!');
            console.log('   Visit http://localhost:3000/hu to see the changes.');
        }

    } catch (error) {
        console.error('Fatal error:', error);
    }
}

updateAllFAQs();
