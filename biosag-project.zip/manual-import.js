
const { createClient } = require('@sanity/client');
const fs = require('fs');

// READ THIS: You need to get a token from https://www.sanity.io/manage
// 1. Log in -> Select Project -> API -> Add New Token -> Give "Editor" permissions
// 2. Paste the token below:
const TOKEN = 'sk...YOUR_TOKEN_HERE...';

const client = createClient({
    projectId: 'beba1xg7',
    dataset: 'production',
    apiVersion: '2024-02-09',
    token: TOKEN,
    useCdn: false,
});

const content = fs.readFileSync('faqs.ndjson', 'utf8');
const lines = content.trim().split('\n');

async function importFaqs() {
    console.log(`Starting import of ${lines.length} FAQs...`);

    const transaction = client.transaction();

    lines.forEach(line => {
        const doc = JSON.parse(line);
        transaction.create(doc);
    });

    try {
        const result = await transaction.commit();
        console.log('Successfully imported FAQs!', result);
    } catch (err) {
        console.error('Import failed:', err.message);
    }
}

// Only run if token is set
if (TOKEN.startsWith('sk')) {
    importFaqs();
} else {
    console.log('Please set a valid API token in manual-import.js first!');
}
